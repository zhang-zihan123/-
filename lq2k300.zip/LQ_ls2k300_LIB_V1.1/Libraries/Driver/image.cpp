#include"image.hpp"
#include"imgdeal.hpp"
#include"encoder.hpp"
#include"motor.hpp"
#include"steer.hpp"
int img1[CAMERA_H][CAMERA_W];//图像数组
uint8_t img_temp[CAMERA_H][CAMERA_W];
int imgdisplay[CAMERA_H][CAMERA_W];//图像数组

double fps;

std::string ImageStatusToString(RoadType_e Road_type) 
{

        switch (Road_type) 
        {
            case zero:
                return "zero";
            case Normol:
                return "Normol";
            case Straight:
                return "Straight";
            case Cross:
                return "Cross";
            case Ramp:
                return "Ramp";
            case LeftCirque:
                return "LeftCirque";
            case RightCirque:
                return "RightCirque";
            case Cross_ture:
                return "Cross_ture";
            default:
                return "Unknown";
        }
    
}
uint8_t Threshold_real;
uint8_t Threshold_deal(uint8_t* image,
    uint16_t col,
    uint16_t row,
    uint16_t pixel_threshold)
{
    #define GrayScale 256
    uint16_t width = CAMERA_W;
    uint16_t height = CAMERA_H;
    int pixelCount[GrayScale];
    float pixelPro[GrayScale];
    int i, j, pixelSum = width * height;
    uint8_t threshold = 0;
    uint8_t* data = image;  //指向像素数据的指针
    for (i = 0; i < GrayScale; i++) {
        pixelCount[i] = 0;
        pixelPro[i] = 0;
    }

    uint32_t gray_sum = 0;
    //统计灰度级中每个像素在整幅图像中的个数
    for (i = 0; i < height; i += 1) {
        for (j = 0; j < width; j += 1) {
            // if((sun_mode&&data[i*width+j]<pixel_threshold)||(!sun_mode))
            //{
            pixelCount[(
                int)data[i * width + j]]++;  //将当前的点的像素值作为计数数组的下标
            gray_sum += (int)data[i * width + j];  //灰度值总和
            //}
        }
    }

    //计算每个像素值的点在整幅图像中的比例
    for (i = 0; i < GrayScale; i++) {
        pixelPro[i] = (float)pixelCount[i] / pixelSum;
    }


    //遍历灰度级[0,255]
    float w0, w1, u0tmp, u1tmp, u0, u1, u, deltaTmp, deltaMax = 0;
    w0 = w1 = u0tmp = u1tmp = u0 = u1 = u = deltaTmp = 0;
    for (j = 0; j < pixel_threshold; j++) {
        w0 +=
            pixelPro[j];  //背景部分每个灰度值的像素点所占比例之和 即背景部分的比例
        u0tmp += j * pixelPro[j];  //背景部分 每个灰度值的点的比例 *灰度值

        w1 = 1 - w0;
        u1tmp = gray_sum / pixelSum - u0tmp;

        u0 = u0tmp / w0;    //背景平均灰度
        u1 = u1tmp / w1;    //前景平均灰度
        u = u0tmp + u1tmp;  //全局平均灰度
        deltaTmp = w0 * pow((u0 - u), 2) + w1 * pow((u1 - u), 2);
        if (deltaTmp > deltaMax) {
            deltaMax = deltaTmp;
            threshold = j;
        }
        if (deltaTmp < deltaMax) break;
    }
    return threshold;
}



void erzhihua(Mat img)
{
    Mat img_gaussian, img_gray, img_threshold,gray;
    cvtColor(img, img_gray, COLOR_BGR2GRAY);
    GaussianBlur(img_gray, img_gaussian, Size(5, 5), 0);
    
    resize(img_gaussian, gray, Size(160, 120));

    for(int i=60,p=0;i<120;i++,p++)
    {
        for(int j=0,k=0;j<160;j+=2,k++) 
        {
            img_temp[p][k]=gray.at<unsigned char>(i, j);
        }
    }
    // threshold(img_gaussian, img_threshold, 0, 255, THRESH_BINARY + THRESH_OTSU);
    Threshold_real = Threshold_deal(img_temp[0], CAMERA_W, CAMERA_H, 200)+15;

    for (int i = 0; i < 60; i+=1)
    {
        for (int j = 0; j < 80; j+=1)
        {  
            // img3[i][j]=binary.at<unsigned char>(i, j);
            if(img_temp[i][j]>Threshold_real){img1[i][j]=1;}
            else {img1[i][j]=0;}
            // img3[i][j] = img_temp[i][j];
        }
       
    }
       

}


void printfshuzu() 
{
    ImageStatus.offline=ImageStatus.OFFLine;
    cout << endl << endl;
    cout << "fps:" << fps << "    ";
    cout << "顶行:" << ImageStatus.offline << endl;
    cout << "前瞻:" << ImageStatus.TowPoint_True << "    ";
    cout << "中点:" << ImageStatus.Det_True << "    ";

    cout << "ImageStatus.OFFLine:"<< static_cast<int>(ImageStatus.OFFLine);
    cout << "ImageStatus.Left_Line:" << static_cast<int>(ImageStatus.Left_Line) << "    " << "ImageStatus.Right_Line:" << static_cast<int>(ImageStatus.Right_Line) << endl;
    cout << "Right_RingsFlag_Point1_Ysite:" << Right_RingsFlag_Point1_Ysite << "    " << "Right_RingsFlag_Point2_Ysite:" << Right_RingsFlag_Point2_Ysite << endl;
    cout << "圆环进程:" << ImageFlag.image_element_rings_flag <<"    "<< "标记" << szr;

    
    std::cout << "The current road type is: " << ImageStatusToString(ImageStatus.Road_type) << std::endl;
    cout<<"左编码器"<<speed_l<<"     "<<"右编码器"<<speed_r<<"     "<<"Speed_Goal";
    cout<<"左速度"<<Speed_Goal_r<<"     "<<"右速度"<<Speed_Goal_r<<"     "<<"Speed_Goal"<<Speed_Goal<<endl;
    cout<<"左PWM"<<Speed_PID_OUT_l<<"     "<<"右PWM"<<Speed_PID_OUT_r<<endl;
    cout<<"偏差"<<ImageStatus.Det_True-32<<"前瞻"<<ImageStatus.TowPoint<<endl;
    cout << endl << endl;
    
    for (int y = 0; y < CAMERA_H; y++)
    {
        stringstream ss;
        for (int x = 0; x < CAMERA_W; x++)
        {
            ss << img1[y][x];
        }
        string result = ss.str();
        cout << result << endl;
    }
        
}
