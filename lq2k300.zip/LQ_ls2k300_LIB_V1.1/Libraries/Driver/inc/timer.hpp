#ifndef TIMER_H
#define TIMER_H

#include"main.hpp"


// 函数声明
void timer_handler(int signum);
void time_init(void);


#endif