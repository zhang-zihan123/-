#ifndef IMAGE_H
#define IMAGE_H

#include"main.hpp"

extern int img1[CAMERA_H][CAMERA_W];//图像数组
extern uint8_t img_temp[CAMERA_H][CAMERA_W];
extern int imgdisplay[CAMERA_H][CAMERA_W];//图像数组

extern double fps;

extern void erzhihua(Mat img);
extern void printfshuzu(void) ;



#endif