/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
@编   写：龙邱科技
@邮   箱：chiusir@163.com
@编译IDE：Linux 环境、VSCode_1.93 及以上版本、Cmake_3.16 及以上版本
@使用平台：龙芯2K0300久久派和北京龙邱智能科技龙芯久久派拓展板
@相关信息参考下列地址
    网      站：http://www.lqist.cn
    淘 宝 店 铺：http://longqiu.taobao.com
    程序配套视频：https://space.bilibili.com/95313236
@软件版本：V1.0 版权所有，单位使用请先联系授权
@参考项目链接：https://github.com/AirFortressIlikara/ls2k0300_peripheral_library

@修改日期：2025-02-26
@修改内容：
@注意事项：注意查看路径的修改
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/

#include "main.hpp"




// 蜂鸣器引脚初始化
HWGpio beep(12, GPIO_Mode_Out);

long szr;
PWM_ATIM steer_test(86, 0b11, 3, 2000000-1, 128050, 1);

//GtimPwm MyPwm(86, 2, LS_GTIM_INVERSED, 2000000 - 1, 150000);

// 定义定时器间隔（5ms）
// const auto timer_interval = std::chrono::milliseconds(5);

// 定义定时器间隔（5ms）
const auto timer_interval_1 = std::chrono::milliseconds(5);
// 定义定时器间隔（20ms）
const auto timer_interval_2 = std::chrono::milliseconds(20);



ENCODER encoder_l(0, 51);//左编码器初始化
ENCODER encoder_r(3, 50);//右编码器初始化
PWM_ls test_l(1, 10000, 8000);//这里的占空比是低电位所占比例  改周期时要将上方setDutyCycle中的10000也改掉
PWM_ls test_r(2, 10000, 8000);//这里的占空比是低电位所占比例  改周期时要将上方setDutyCycle中的10000也改掉
GPIO motor_l(73);//左电机方向脚初始化
GPIO motor_r(72);//右电机方向脚初始化


void timer_thread_1()
{
    while (true)
    {
        speed_l = encoder_l.pulse_counter_update();
        speed_r = -encoder_r.pulse_counter_update();
        //Motor_Control();  //电机PWM转换

        Speed_PID_OUT_r=1500;
        Speed_PID_OUT_l=1500;

        if(Speed_PID_OUT_r >= 0)                         
        {motor_r.setValue(0);test_r.setDutyCycle(Speed_PID_OUT_r);}
        else{motor_r.setValue(1);test_r.setDutyCycle(-Speed_PID_OUT_r);}
        if(Speed_PID_OUT_l >= 0)                         
        {motor_l.setValue(0);test_l.setDutyCycle(Speed_PID_OUT_l);}
        else{motor_l.setValue(1);test_l.setDutyCycle(-Speed_PID_OUT_l);}

        std::this_thread::sleep_for(timer_interval_1);
    }
}

// 方向环定时器
void timer_thread_2()
{
    while (true)
    {
        SteerPID_Realize(ImageStatus.Det_True - ImageStatus.MiddleLine);//舵机PID计算
        steer_test.setDutyCycle(PWM_STEER);
        std::this_thread::sleep_for(timer_interval_2);
    }
}




int main()

    {
   // beep.SetGpioValue(0);   // 关闭蜂鸣器
      //PWM_ATIM steer_test(89, 0b11, 3, 20000000, 1700,1);
    //PWM_ATIM steer_test(86, 0b11, 3, 2000000-1, 128050, 1);
    Mat img, img_erzhi;
    int fps_count = 0;
    auto start_time = high_resolution_clock::now(); // 开始时间
    VideoCapture cap(0);
    if (!cap.isOpened()) {cerr << "Could not open the camera" << endl;return -1;}

    test_l.enable();
    test_r.enable();
    test_l.setPeriod(10000);//改周期时要将上方setDutyCycle中的10000也改掉
    test_r.setDutyCycle(2000);//这个里的占空比是指高电位所占比例
    test_l.setPeriod(10000);//改周期时要将上方setDutyCycle中的10000也改掉
    test_r.setDutyCycle(2000);//这里的占空比是低电位所占比例

    steer_test.enable();//右电机初始化 
    steer_test.setPeriod(20000000);

    motor_l.setDirection("out");motor_l.setValue(0);//左电机方向脚初始化
    motor_r.setDirection("out");motor_r.setValue(0);//右电机方向脚初始化
    

    Speed_decision();
    Data_Settings();
    InitMH();
    string command;

    /***********************************摄像头初始化******************************* */  
    cap.set(cv::CAP_PROP_AUTO_EXPOSURE, 1);
    cap.set(cv::CAP_PROP_FRAME_WIDTH, 320);  // 设置分辨率宽度为640  320
    cap.set(cv::CAP_PROP_FRAME_HEIGHT, 240); // 设置分辨率高度为480  240
    cap.set(cv::CAP_PROP_FOURCC, cv::VideoWriter::fourcc('M', 'J', 'P', 'G')); // 设置视频编码格式为MJPG
 ///
    cap.set(cv::CAP_PROP_FPS, 120); // 设置帧率为120 FPS

    // // // // 设置其他摄像头参数
    // cap.set(cv::CAP_PROP_BRIGHTNESS, 0);       // 亮度
    // cap.set(cv::CAP_PROP_CONTRAST, 32);        // 对比度
    // cap.set(cv::CAP_PROP_HUE, 0);              // 色调
    // cap.set(cv::CAP_PROP_SATURATION, 60);      // 饱和度
    // cap.set(cv::CAP_PROP_SHARPNESS, 2);        // 清晰度
    // cap.set(cv::CAP_PROP_GAMMA, 100);          // 伽马
    // cap.set(cv::CAP_PROP_WHITE_BALANCE_BLUE_U, 6500); // 白平衡
    // cap.set(cv::CAP_PROP_BACKLIGHT, 1);        // 逆光对比
    // cap.set(cv::CAP_PROP_GAIN, 0);             // 增益
    cap.set(cv::CAP_PROP_AUTO_EXPOSURE, 3);   // 关闭自动曝光
    cap.set(cv::CAP_PROP_AUTO_EXPOSURE, 0);   // 再关闭自动曝光
    cap.set(cv::CAP_PROP_EXPOSURE, 156);      // 曝光
    
    // //关闭自动曝光
    // //cap.set(cv::CAP_PROP_AUTO_EXPOSURE, 1);
    // cap.set(cv::CAP_PROP_AUTOFOCUS, 0);        // 自动对焦
    // cap.set(cv::CAP_PROP_ZOOM, 1);             // 缩放
    // cap.set(cv::CAP_PROP_FOCUS, 0);            // 对焦
    // cap.set(cv::CAP_PROP_TEMPERATURE, 6500);   // 色温
    // cap.set(cv::CAP_PROP_TRIGGER, 0);          // 触发
    // cap.set(cv::CAP_PROP_TRIGGER_DELAY, 0);    // 触发延迟
    // cap.set(cv::CAP_PROP_WHITE_BALANCE_RED_V, 4600); // 红色白平衡
    // cap.set(cv::CAP_PROP_PAN, 0);              // 平移
    // cap.set(cv::CAP_PROP_TILT, 0);             // 倾斜
    // cap.set(cv::CAP_PROP_ROLL, 0);             // 滚动
    // cap.set(cv::CAP_PROP_IRIS, 0);             // 光圈
    // cap.set(cv::CAP_PROP_SETTINGS, 0);         // 设置
    // cap.set(cv::CAP_PROP_BUFFERSIZE, 10);       // 缓冲区大小
    // cap.set(cv::CAP_PROP_SAR_NUM, 1);          // 样本纵横比：分子
    // cap.set(cv::CAP_PROP_SAR_DEN, 1);          // 样本纵横比：分母
    // cap.set(cv::CAP_PROP_CHANNEL, 0);          // 视频输入或通道号
    // cap.set(cv::CAP_PROP_AUTO_WB, 0);          // 自动白平衡
    // cap.set(cv::CAP_PROP_WB_TEMPERATURE, 4600); // 白平衡色温
    /***************************************************************************** */
    // std::thread threadA(timer_thread);
    // threadA.detach(); // 分离线程，允许后台运行



    // 分离线程，允许后台运行
    std::thread threadA(timer_thread_1);
    std::thread threadB(timer_thread_2);
    threadA.detach();
    threadB.detach();
   
   
    
  
       
    while (true) 
    {

      // beep.SetGpioValue(1);   // 蜂鸣器

        // 从摄像头读取一帧图像
        cap >> img;if (img.empty()){break;}

        erzhihua(img);
        fps_count++;
        if (fps_count % 5 == 0)// 每10帧计算一次FPS
        {
            auto end_time = high_resolution_clock::now(); // 结束时间
            duration<double> time_span = end_time-start_time; // 计算时间差
            fps = fps_count / time_span.count(); // 计算帧率
            fps_count = 0; // 重置帧数计数
            start_time = high_resolution_clock::now(); // 重置开始时间
            printfshuzu(); 
        }

        //beep.SetGpioValue(0);   // 蜂鸣器
         
    
        imageprocess();//图像处理

      
    
      
    }
    cap.release();


    return 0;
}